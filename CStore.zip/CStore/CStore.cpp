#include "CStore.h"
#include <nlohmann/json.hpp>
#include <fstream>

CStore::CStore(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
    connect(ui.tovarButton, SIGNAL(released()), this, SLOT(tovarButton()));
    connect(ui.orderButton, SIGNAL(released()), this, SLOT(orderButton()));
    ui.tableWidget->setSortingEnabled(true);
}

void CStore::tovarButton()
{
    fillTable("tovar", { "id", "name", "price", "number" }, { "ID", "Name", "Price", "Number" });
}

void CStore::orderButton()
{
    fillTable("order", { "id", "id_tovar", "count", "date" }, { "ID", "TovarID", "Count", "Date" });
}

void CStore::fillTable(std::string name, std::vector<std::string> keys, QStringList labels)
{
    std::fstream fileInput;
    using json = nlohmann::json;
    json file;
    fileInput.open("data/data.json");
    fileInput >> file;
    int ColumnCount = file[name][0].size();
    int RowCount = file[name].size();
    ui.tableWidget->setColumnCount(ColumnCount);
    ui.tableWidget->setRowCount(RowCount);
    ui.tableWidget->setHorizontalHeaderLabels(labels);
    for (int column = 0; column < ColumnCount; ++column)
    {
        for (int row = 0; row < RowCount; ++row)
        {
            QTableWidgetItem* its = new QTableWidgetItem
            (QString::fromStdString(file[name][row][keys[column]].dump()));
            ui.tableWidget->setItem(row, column, its);
        }
    }
    fileInput.close();
    return;
}
