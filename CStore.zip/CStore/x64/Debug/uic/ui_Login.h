/********************************************************************************
** Form generated from reading UI file 'Login.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Login
{
public:
    QWidget *widget;
    QLineEdit *lineLogin;
    QLineEdit *linePass;
    QPushButton *pushButtonLogin;
    QLabel *logo;

    void setupUi(QWidget *Login)
    {
        if (Login->objectName().isEmpty())
            Login->setObjectName(QString::fromUtf8("Login"));
        Login->resize(567, 577);
        Login->setStyleSheet(QString::fromUtf8("QPushButton:hover{\n"
"  background-color:rgb(42, 77, 159);\n"
"  color: white;\n"
"  border-radius:15px;\n"
"}\n"
"\n"
"QPushButton:pressed{\n"
"  background-color:rgb(64, 118, 243);\n"
"  color: white;\n"
"  border-radius:15px;\n"
"}\n"
"\n"
"QPushButton{\n"
"background-color:#3867d6;\n"
"color: white;\n"
"border-radius:15px;\n"
"}"));
        widget = new QWidget(Login);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(60, 40, 481, 521));
        widget->setStyleSheet(QString::fromUtf8("border-radius:20px;\n"
"background-color:#FFFFFF;"));
        lineLogin = new QLineEdit(widget);
        lineLogin->setObjectName(QString::fromUtf8("lineLogin"));
        lineLogin->setGeometry(QRect(70, 250, 351, 61));
        QFont font;
        font.setPointSize(15);
        lineLogin->setFont(font);
        lineLogin->setStyleSheet(QString::fromUtf8("border-radius:17px;\n"
"background-color:#F5F5F5;\n"
"padding-left:25px;\n"
"color:#616161;\n"
""));
        linePass = new QLineEdit(widget);
        linePass->setObjectName(QString::fromUtf8("linePass"));
        linePass->setGeometry(QRect(70, 350, 351, 61));
        linePass->setFont(font);
        linePass->setStyleSheet(QString::fromUtf8("border-radius:17px;\n"
"background-color:#F5F5F5;\n"
"padding-left:25px;\n"
"color:#616161"));
        linePass->setEchoMode(QLineEdit::Password);
        pushButtonLogin = new QPushButton(widget);
        pushButtonLogin->setObjectName(QString::fromUtf8("pushButtonLogin"));
        pushButtonLogin->setGeometry(QRect(80, 440, 331, 55));
        QFont font1;
        font1.setPointSize(15);
        font1.setBold(true);
        pushButtonLogin->setFont(font1);
        pushButtonLogin->setCursor(QCursor(Qt::PointingHandCursor));
        pushButtonLogin->setStyleSheet(QString::fromUtf8("QPushButton:hover{\n"
"  background-color:rgb(42, 77, 159);\n"
"  color: white;\n"
"  border-radius:15px;\n"
"}\n"
"\n"
"QPushButton:pressed{\n"
"  background-color:rgb(64, 118, 243);\n"
"  color: white;\n"
"  border-radius:15px;\n"
"}\n"
"\n"
"QPushButton{\n"
"background-color:red;\n"
"color: white;\n"
"border-radius:15px;\n"
"}"));
        logo = new QLabel(widget);
        logo->setObjectName(QString::fromUtf8("logo"));
        logo->setGeometry(QRect(170, 90, 150, 120));
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(logo->sizePolicy().hasHeightForWidth());
        logo->setSizePolicy(sizePolicy);
        logo->setMinimumSize(QSize(150, 120));
        logo->setMaximumSize(QSize(150, 120));
        logo->setPixmap(QPixmap(QString::fromUtf8(":/images/images/Logo.svg")));

        retranslateUi(Login);

        QMetaObject::connectSlotsByName(Login);
    } // setupUi

    void retranslateUi(QWidget *Login)
    {
        Login->setWindowTitle(QCoreApplication::translate("Login", "Form", nullptr));
        lineLogin->setPlaceholderText(QCoreApplication::translate("Login", "\320\233\320\276\320\263\321\226\320\275", nullptr));
        linePass->setPlaceholderText(QCoreApplication::translate("Login", "\320\237\320\260\321\200\320\276\320\273\321\214", nullptr));
        pushButtonLogin->setText(QCoreApplication::translate("Login", "\320\243\320\262\321\226\320\271\321\202\320\270", nullptr));
        logo->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Login: public Ui_Login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
